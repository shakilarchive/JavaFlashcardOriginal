package javaFlashcard;

import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FlashcardTimer {
    private Timer timer;
    private Date startTime;
    private SimpleDateFormat timeFormat;
    private JavaFlashcard mainClass;

    public FlashcardTimer(final JavaFlashcard mainClass) {
        this.mainClass = mainClass;
        timeFormat = new SimpleDateFormat("HH:mm:ss");
        startTime = new Date();
        timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Calculate elapsed time
                long elapsedTime = new Date().getTime() - startTime.getTime();
                String formattedTime = formatTime(elapsedTime);
                // Pass the formatted time to the JavaFlashcard class
                mainClass.updateTimer(formattedTime);
            }
        });
    }

    public void start() {
        timer.start();
    }

    public void stop() {
        timer.stop();
    }

    private String formatTime(long milliseconds) {
        long seconds = milliseconds / 1000;
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        seconds = seconds % 60;
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }
}
