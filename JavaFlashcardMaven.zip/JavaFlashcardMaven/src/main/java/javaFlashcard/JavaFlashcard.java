package javaFlashcard;

import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.geom.Rectangle2D;
import java.util.List;
import java.util.stream.Collectors;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class JavaFlashcard extends JFrame {
    private JLabel flashcardLabel;
    private JLabel timerLabel;
    private JLabel cardNumberLabel;
    private JLabel sheetProgressLabel;
    private JComboBox<String> sheetComboBox;
    private KeyControl keyControl;
    private List<String> questions;
    private List<String> answers;
    private int currentIndex = 0;
    private boolean isAnswerVisible = false;
    private FlashcardTimer flashcardTimer;

    public JavaFlashcard() {
        initializeUI();
        loadSelectedSheet();
    }

    private void initializeUI() {
        setTitle("Java Flashcard App");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLayout(new BorderLayout());

        createSheetPanel();
        createFlashcardLabel();
        createCardNumberLabel();
        createTimerLabel();
        createSheetProgressLabel();
        createYourButtons();

        keyControl = new KeyControl(this);
        addKeyListener(keyControl);
        setFocusable(true);
        requestFocusInWindow();

        flashcardTimer = new FlashcardTimer(this);
        flashcardTimer.start();
    }

    private void createSheetPanel() {
        sheetComboBox = new JComboBox<>(FlashcardData.getSheetNames().toArray(new String[0]));
        sheetComboBox.setSelectedIndex(0);
        sheetComboBox.addActionListener(e -> loadSelectedSheet());

        JPanel sheetPanel = new JPanel();
        sheetPanel.add(new JLabel("Select a Sheet: "));
        sheetPanel.add(sheetComboBox);
        add(sheetPanel, BorderLayout.NORTH);
    }

    private void createFlashcardLabel() {
        flashcardLabel = new JLabel("");
        flashcardLabel.setFont(new Font("Arial", Font.PLAIN, 36));
        flashcardLabel.setHorizontalAlignment(JLabel.CENTER);
        add(flashcardLabel, BorderLayout.CENTER);
    }

    private void createCardNumberLabel() {
        cardNumberLabel = new JLabel("");
        cardNumberLabel.setFont(new Font("Arial", Font.PLAIN, 24));
        cardNumberLabel.setHorizontalAlignment(JLabel.CENTER);
        add(cardNumberLabel, BorderLayout.SOUTH);
    }

    private void createTimerLabel() {
        timerLabel = new JLabel("Time Elapsed: 00:00:00");
        timerLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        timerLabel.setHorizontalAlignment(JLabel.CENTER);
        add(timerLabel, BorderLayout.SOUTH);
    }

    private void createSheetProgressLabel() {
        sheetProgressLabel = new JLabel("");
        sheetProgressLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        sheetProgressLabel.setHorizontalAlignment(SwingConstants.LEFT);
        sheetProgressLabel.setVerticalAlignment(SwingConstants.TOP);
        int padding = 10;
        sheetProgressLabel.setBorder(new EmptyBorder(padding, padding, padding, padding));
        add(sheetProgressLabel, BorderLayout.WEST);
    }

    private void createYourButtons() {
        JButton yourButtonCopy = new JButton("Copy Text");
        yourButtonCopy.addActionListener(e -> {
            String htmlToCopy = flashcardLabel.getText();
            if (!htmlToCopy.isEmpty()) {
                // Parse the HTML content
                Document doc = Jsoup.parse(htmlToCopy);

                // Get the plain text
                String textToCopy = doc.text();

                // Copy the plain text to the system clipboard
                Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                clipboard.setContents(new StringSelection(textToCopy), null);

                // Show a message indicating that the text has been copied
                // JOptionPane.showMessageDialog(JavaFlashcard.this, "Text copied to clipboard: \n" + textToCopy);

                // Set focus to the main window to ensure continued keyboard control
                JavaFlashcard.this.requestFocusInWindow();
            }
        });

        JButton yourButtonBox = new JButton("Show Text Box");
        yourButtonBox.addActionListener(e -> {
            String htmlToCopy = flashcardLabel.getText();
            if (!htmlToCopy.isEmpty()) {
                // Parse the HTML content
                Document doc = Jsoup.parse(htmlToCopy);

                // Get the plain text
                String textToCopy = doc.text();

                // Create a JTextArea with a fixed font size of 36
                JTextArea textArea = new JTextArea(textToCopy);
                textArea.setFont(new Font("Arial", Font.PLAIN, 36));
                textArea.setWrapStyleWord(true);
                textArea.setLineWrap(true);
                textArea.setCaretPosition(0);
                textArea.setEditable(false);

                // Create a JScrollPane for the text area
                JScrollPane scrollPane = new JScrollPane(textArea);

                // Create a JDialog to display the text area
                JDialog dialog = new JDialog();
                dialog.setTitle("Copied Text");
                dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
                dialog.getContentPane().add(scrollPane);

                // Set the dialog size to match the screen size
                GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
                GraphicsDevice gd = ge.getDefaultScreenDevice();
                Rectangle2D screenBounds = gd.getDefaultConfiguration().getBounds();
                int screenWidth = (int) screenBounds.getWidth();
                int screenHeight = (int) screenBounds.getHeight();
                dialog.setSize(screenWidth, screenHeight);

                // Center the dialog on the screen (optional)
                dialog.setLocationRelativeTo(null);

                // Show the dialog
                dialog.setVisible(true);

                // Set focus to the main window to ensure continued keyboard control
                JavaFlashcard.this.requestFocusInWindow();
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.add(yourButtonCopy);
        buttonPanel.add(yourButtonBox);
        add(buttonPanel, BorderLayout.EAST);
    }

    private void loadSelectedSheet() {
        String selectedSheetName = (String) sheetComboBox.getSelectedItem();
        questions = FlashcardData.getQuestions(selectedSheetName);
        answers = FlashcardData.getAnswers(selectedSheetName);

        questions = questions.stream().filter(q -> !q.isEmpty()).collect(Collectors.toList());
        answers = answers.stream().filter(a -> !a.isEmpty()).collect(Collectors.toList());

        currentIndex = 0;
        isAnswerVisible = false;
        showQuestion();

        requestFocusInWindow();

        sheetProgressLabel.setText("1 of " + questions.size());
    }

    void toggleAnswer() {
        isAnswerVisible = !isAnswerVisible;
        showQuestion();
    }

    void moveToNextCard() {
        currentIndex = (currentIndex + 1) % questions.size();
        isAnswerVisible = false;
        showQuestion();
    }

    void moveToPrevCard() {
        currentIndex = (currentIndex - 1 + questions.size()) % questions.size();
        isAnswerVisible = false;
        showQuestion();
    }


	private void showQuestion() {
		if (questions.isEmpty()) {
			flashcardLabel.setText("No questions available for this sheet.");
			cardNumberLabel.setText("");
		} else {
			String questionText = isAnswerVisible ? answers.get(currentIndex) : questions.get(currentIndex);
			flashcardLabel.setText("<html><div style='text-align: center;'>" + questionText + "</div></html");

			cardNumberLabel.setText("Flashcard " + (currentIndex + 1) + " of " + questions.size());
			sheetProgressLabel.setText((currentIndex + 1) + " of " + questions.size());
		}
	}

	void updateTimer(String formattedTime) {
		timerLabel.setText("Time Elapsed: " + formattedTime);
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			JavaFlashcard flashcardApp = new JavaFlashcard();
			flashcardApp.setVisible(true);
		});
	}
}