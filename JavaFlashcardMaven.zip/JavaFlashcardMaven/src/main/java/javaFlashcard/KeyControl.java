


package javaFlashcard;

import java.awt.event.KeyEvent;
import java.awt.event.KeyAdapter;

public class KeyControl extends KeyAdapter {
    private JavaFlashcard flashcardApp;

    public KeyControl(JavaFlashcard flashcardApp) {
        this.flashcardApp = flashcardApp;
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int keyCode = e.getKeyCode();
        if (keyCode == KeyEvent.VK_ENTER) {
            flashcardApp.toggleAnswer();
        } else if (keyCode == KeyEvent.VK_RIGHT || keyCode == KeyEvent.VK_SHIFT) {
            flashcardApp.moveToNextCard();
        } else if (keyCode == KeyEvent.VK_LEFT) {
            flashcardApp.moveToPrevCard();
        }
    }
}
