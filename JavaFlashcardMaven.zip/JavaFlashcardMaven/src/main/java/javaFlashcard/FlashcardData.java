package javaFlashcard;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FlashcardData {
    private static final String EXCEL_PATH_FILE = "excel_path.txt";

    private static String getExcelFilePath() throws IOException {
        try (Scanner scanner = new Scanner(new File(EXCEL_PATH_FILE))) {
            if (scanner.hasNextLine()) {
                return scanner.nextLine();
            } else {
                throw new IOException("excel_path.txt is empty");
            }
        }
    }

    private static Workbook openWorkbook() throws IOException {
        String excelFilePath = getExcelFilePath();
        FileInputStream inputStream = new FileInputStream(excelFilePath);
        return new XSSFWorkbook(inputStream);
    }

    public static List<String> getSheetNames() {
        List<String> sheetNames = new ArrayList<>();

        try (Workbook workbook = openWorkbook()) {
            int numberOfSheets = workbook.getNumberOfSheets();
            for (int i = 0; i < numberOfSheets; i++) {
                sheetNames.add(workbook.getSheetName(i));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return sheetNames;
    }

    public static List<String> getQuestions(String sheetName) {
        List<String> questions = new ArrayList<>();

        try (Workbook workbook = openWorkbook()) {
            Sheet sheet = workbook.getSheet(sheetName);

            for (Row row : sheet) {
                Cell questionCell = row.getCell(0);
                if (questionCell != null) {
                    questions.add(questionCell.getStringCellValue());
                } else {
                    questions.add("");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return questions;
    }

    public static List<String> getAnswers(String sheetName) {
        List<String> answers = new ArrayList<>();

        try (Workbook workbook = openWorkbook()) {
            Sheet sheet = workbook.getSheet(sheetName);

            for (Row row : sheet) {
                Cell answerCell = row.getCell(1);
                if (answerCell != null) {
                    answers.add(answerCell.getStringCellValue());
                } else {
                    answers.add("");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return answers;
    }

    public static void main(String[] args) {
        // Example usage:
        List<String> sheetNames = getSheetNames();
        System.out.println("Sheet Names: " + sheetNames);

        String sheetName = sheetNames.get(0); // Assuming you want to read the first sheet.
        List<String> questions = getQuestions(sheetName);
        List<String> answers = getAnswers(sheetName);

        for (int i = 0; i < questions.size(); i++) {
            System.out.println("Question: " + questions.get(i));
            System.out.println("Answer: " + answers.get(i));
        }
    }
}
